function coeffsNormalized = SLnormalizeCoefficients3D(coeffs,shearletSystem)
%SLNORMALIZECOEFFICIENTS Summary of this function goes here
%   Detailed explanation goes here

    useGPU = isa(coeffs,'gpuArray');

    if useGPU
        if verLessThan('distcomp','6.1')
            coeffsNormalized = parallel.gpu.GPUArray.zeros(size(coeffs));
        else
            coeffsNormalized = gpuArray.zeros(size(coeffs));
        end
    else
        coeffsNormalized = zeros(size(coeffs));
    end

    for i = 1:shearletSystem.nShearlets
        coeffsNormalized(:,:,:,i) = coeffs(:,:,:,i)./shearletSystem.RMS(i);
    end
end

%
%  Copyright (c) 2014. Rafael Reisenhofer
%
%  Part of ShearLab3D v1.1
%  Built Mon, 10/11/2014
%  This is Copyrighted Material
%
%  If you use or mention this code in a publication please cite the website www.shearlab.org and the following paper:
%  G. Kutyniok, W.-Q. Lim, R. Reisenhofer
%  ShearLab 3D: Faithful Digital SHearlet Transforms Based on Compactly Supported Shearlets.
%  ACM Trans. Math. Software 42 (2016), Article No.: 5.
